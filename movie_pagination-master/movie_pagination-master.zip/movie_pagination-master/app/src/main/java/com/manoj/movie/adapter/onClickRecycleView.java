package com.manoj.movie.adapter;

import android.view.View;

public interface onClickRecycleView {
    void onItemClick(View view, int position);
}
